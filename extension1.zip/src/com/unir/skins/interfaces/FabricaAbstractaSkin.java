package com.unir.skins.interfaces;

public interface FabricaAbstractaSkin{

    PrendaPiesAbstracta crearPrendaPiesAbstracta();
    PrendaInferiorAbstracta crearPrendaInferiorAbstracta();
    PrendaSuperiorAbstracta crearPrendaSuperiorAbstracta();
}
