package com.unir.skins.interfaces;

public interface PrendaInferiorAbstracta {
    void crearPrenda();
}
