package com.unir.skins.prendas.invierno;

import com.unir.skins.interfaces.PrendaInferiorAbstracta;

public class InferiorInvierno implements PrendaInferiorAbstracta {

    @Override
    public void crearPrenda() {
        System.out.println("Se ha creado una prenda inferior de invierno");
    }
}
