package com.unir.skins.interfaces;

public interface PrendaSuperiorAbstracta {
    void crearPrenda();
}
