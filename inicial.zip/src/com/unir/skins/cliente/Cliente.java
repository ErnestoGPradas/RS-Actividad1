package com.unir.skins.cliente;

import com.unir.skins.interfaces.*;

public class Cliente {

    private PrendaPiesAbstracta prendaPiesAbstracta;
    private PrendaInferiorAbstracta prendaInferiorAbstracta;
    private PrendaSuperiorAbstracta prendaSuperiorAbstracta;

    public Cliente(FabricaAbstractaSkin fabricaAbstractaSkin){
        prendaPiesAbstracta = fabricaAbstractaSkin.crearPrendaPiesAbstracta();
        prendaInferiorAbstracta = fabricaAbstractaSkin.crearPrendaInferiorAbstracta();
        prendaSuperiorAbstracta = fabricaAbstractaSkin.crearPrendaSuperiorAbstracta();
    }

    public void crearProductos(){
        prendaPiesAbstracta.crearPrenda();
        prendaInferiorAbstracta.crearPrenda();
        prendaSuperiorAbstracta.crearPrenda();
    }
}
