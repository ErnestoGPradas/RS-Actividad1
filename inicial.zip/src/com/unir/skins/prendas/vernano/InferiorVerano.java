package com.unir.skins.prendas.vernano;

import com.unir.skins.interfaces.PrendaInferiorAbstracta;

public class InferiorVerano implements PrendaInferiorAbstracta {
    @Override
    public void crearPrenda() {
        System.out.println("Se ha creado una prenda inferior de verano");
    }
}
