package com.unir.skins.prendas.invierno;

import com.unir.skins.interfaces.PrendaPiesAbstracta;

public class CubrePiesInvierno implements PrendaPiesAbstracta {

    @Override
    public void crearPrenda() {
        System.out.println("Se ha creado un cubre pies de invierno");
    }
}
