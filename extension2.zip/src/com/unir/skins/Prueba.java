package com.unir.skins;

import com.unir.skins.cliente.Cliente;
import com.unir.skins.fabricas.FabricaConcretaHalloween;
import com.unir.skins.fabricas.FabricaConcretaInvierno;
import com.unir.skins.fabricas.FabricaConcretaVerano;

public class Prueba {

    public static void main(String[] args) {

        System.out.println("Se crea una skin de verano:");
        Cliente skin_verano = new Cliente(new FabricaConcretaVerano());
        skin_verano.crearProductos();

        System.out.println("Se crea una skin de invierno:");
        Cliente skin_invierno = new Cliente( new FabricaConcretaInvierno());
        skin_invierno.crearProductos();

        System.out.println("Se crea una skin de halloween");
        Cliente skin_halloween = new Cliente(new FabricaConcretaHalloween());
        skin_halloween.crearProductos();
    }

}
