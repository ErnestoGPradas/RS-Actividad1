package com.unir.skins.interfaces;

public interface PrendaPiesAbstracta {
    void crearPrenda();
}
