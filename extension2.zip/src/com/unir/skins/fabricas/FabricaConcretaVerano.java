package com.unir.skins.fabricas;

import com.unir.skins.interfaces.*;
import com.unir.skins.prendas.vernano.CapaVerano;
import com.unir.skins.prendas.vernano.CubrePiesVerano;
import com.unir.skins.prendas.vernano.InferiorVerano;
import com.unir.skins.prendas.vernano.SuperiorVerano;

public class FabricaConcretaVerano implements FabricaAbstractaSkin {
    @Override
    public PrendaPiesAbstracta crearPrendaPiesAbstracta() {
        return new CubrePiesVerano();
    }

    @Override
    public PrendaInferiorAbstracta crearPrendaInferiorAbstracta() {
        return new InferiorVerano();
    }

    @Override
    public PrendaSuperiorAbstracta crearPrendaSuperiorAbstracta() {
        return new SuperiorVerano();
    }

    @Override
    public AbrigoAbstracta crearAbrigoAbstracta() {
        return new CapaVerano();
    }

}
