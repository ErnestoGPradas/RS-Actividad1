package com.unir.skins.fabricas;

import com.unir.skins.interfaces.*;
import com.unir.skins.prendas.invierno.AbrigoInvierno;
import com.unir.skins.prendas.invierno.CubrePiesInvierno;
import com.unir.skins.prendas.invierno.InferiorInvierno;
import com.unir.skins.prendas.invierno.SuperiorInvierno;

public class FabricaConcretaInvierno implements FabricaAbstractaSkin {
    @Override
    public PrendaPiesAbstracta crearPrendaPiesAbstracta() {
        return new CubrePiesInvierno();
    }

    @Override
    public PrendaInferiorAbstracta crearPrendaInferiorAbstracta() {
        return new InferiorInvierno();
    }

    @Override
    public PrendaSuperiorAbstracta crearPrendaSuperiorAbstracta() {
        return new SuperiorInvierno();
    }

    @Override
    public AbrigoAbstracta crearAbrigoAbstracta() {
        return new AbrigoInvierno();
    }
}
