package com.unir.skins.cliente;

import com.unir.skins.interfaces.*;

public class Cliente {

    private PrendaPiesAbstracta prendaPiesAbstracta;
    private PrendaInferiorAbstracta prendaInferiorAbstracta;
    private PrendaSuperiorAbstracta prendaSuperiorAbstracta;
    private AbrigoAbstracta abrigoAbstracta;

    public Cliente(FabricaAbstractaSkin fabricaAbstractaSkin){
        prendaPiesAbstracta = fabricaAbstractaSkin.crearPrendaPiesAbstracta();
        prendaInferiorAbstracta = fabricaAbstractaSkin.crearPrendaInferiorAbstracta();
        prendaSuperiorAbstracta = fabricaAbstractaSkin.crearPrendaSuperiorAbstracta();
        abrigoAbstracta = fabricaAbstractaSkin.crearAbrigoAbstracta();
    }

    public void crearProductos(){
        prendaPiesAbstracta.crearPrenda();
        prendaInferiorAbstracta.crearPrenda();
        prendaSuperiorAbstracta.crearPrenda();
        abrigoAbstracta.crearPrenda();
    }
}
