package com.unir.skins.prendas.invierno;

import com.unir.skins.interfaces.PrendaSuperiorAbstracta;

public class SuperiorInvierno implements PrendaSuperiorAbstracta {

    @Override
    public void crearPrenda() {
        System.out.println("Se ha creado una prenda superior de invierno");
    }
}
