package com.unir.skins.prendas.invierno;

import com.unir.skins.interfaces.AbrigoAbstracta;

public class AbrigoInvierno implements AbrigoAbstracta {
    @Override
    public void crearPrenda() {
        System.out.println("Se ha creado un abrigo de invierno");
    }
}
