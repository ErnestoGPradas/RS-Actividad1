package com.unir.skins.prendas.halloween;

import com.unir.skins.interfaces.PrendaSuperiorAbstracta;

public class CamisetaEsqueleto implements PrendaSuperiorAbstracta {
    @Override
    public void crearPrenda() {
        System.out.println("Se ha creado una camiseta de esqueleto");
    }
}
