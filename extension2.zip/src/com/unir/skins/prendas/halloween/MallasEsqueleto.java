package com.unir.skins.prendas.halloween;

import com.unir.skins.interfaces.PrendaInferiorAbstracta;

public class MallasEsqueleto implements PrendaInferiorAbstracta {
    @Override
    public void crearPrenda() {
        System.out.println("Se han creado unas mallas de esqueleto");
    }
}
