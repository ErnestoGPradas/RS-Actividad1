package com.unir.skins.prendas.halloween;

import com.unir.skins.interfaces.AbrigoAbstracta;

public class CapaNegra implements AbrigoAbstracta {
    @Override
    public void crearPrenda() {
        System.out.println("Se ha creado una capa negra");
    }
}
