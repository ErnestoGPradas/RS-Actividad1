package com.unir.skins.prendas.halloween;

import com.unir.skins.interfaces.PrendaPiesAbstracta;

public class ZapatosCalabaza implements PrendaPiesAbstracta {
    @Override
    public void crearPrenda() {
        System.out.println("Se han creado unos zapatos de calabaza");
    }
}
