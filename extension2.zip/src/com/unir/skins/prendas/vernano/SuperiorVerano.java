package com.unir.skins.prendas.vernano;

import com.unir.skins.interfaces.PrendaSuperiorAbstracta;

public class SuperiorVerano implements PrendaSuperiorAbstracta {
    @Override
    public void crearPrenda() {
        System.out.println("Se ha creado una prenda superior de verano");
    }
}
