package com.unir.skins.prendas.vernano;

import com.unir.skins.interfaces.PrendaPiesAbstracta;

public class CubrePiesVerano implements PrendaPiesAbstracta {

    @Override
    public void crearPrenda() {
        System.out.println("Se ha creado un cubre pies de verano");
    }
}
