package com.unir.skins.prendas.vernano;

import com.unir.skins.interfaces.AbrigoAbstracta;

public class CapaVerano implements AbrigoAbstracta {
    @Override
    public void crearPrenda() {
        System.out.println("Se ha creado una capa de verano");
    }
}
